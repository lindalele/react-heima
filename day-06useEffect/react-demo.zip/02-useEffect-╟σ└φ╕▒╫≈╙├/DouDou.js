import React, { useEffect } from 'react'

export default function DouDou({ count }) {
  // 清理副作用的函数：每次副作用的回调函数执行之前执行一次以及组件销毁的时候，
  // 目的：清除上一次的副作用带来的影响    componentWillUnmount
  useEffect(() => {
    console.log('这是副作用函数')
    let timer = setInterval(() => {
      console.log('别打我')
    }, 1000)
    return () => {
      console.log('清理副作用的函数')
      clearInterval(timer)
    }
  }, [])
  return (
    <div>
      <h3>我是豆豆组件，我被打了{count}次</h3>
    </div>
  )
}
