import { Component } from 'react'

export default class Demo extends Component {
  render() {
    return <div>render组件</div>
  }
  sayHi() {
    console.log('大家好')
  }
}
