import { useState } from 'react'

export default function App() {
  const [salary, setSalary] = useState(1000)
  // 需求：得到一个数组，这个数组需要一些额外的判断
  // const [money]
  const level = 1

  const [money, setMoney] = useState(() => {
    if (level === 1) {
      return salary + 10000
    } else if (level === 2) {
      return salary + 20000
    } else {
      return salary + 30000
    }
  })
  return (
    <div>
      <h1>根组件</h1>
      <div>{salary}</div>
    </div>
  )
}
