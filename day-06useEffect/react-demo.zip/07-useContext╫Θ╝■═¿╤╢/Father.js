import React from 'react'
import Son from './Son'
export default function Father() {
  return (
    <div>
      <h2>Father组件</h2>
      <Son></Son>
    </div>
  )
}
