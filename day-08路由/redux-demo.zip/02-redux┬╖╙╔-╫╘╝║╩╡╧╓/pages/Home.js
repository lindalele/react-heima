import React from 'react'

export default function Home() {
  return <div>首页组件</div>
}
