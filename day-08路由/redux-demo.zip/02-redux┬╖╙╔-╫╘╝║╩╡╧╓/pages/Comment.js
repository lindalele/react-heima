import React from 'react'

export default function Comment() {
  return <div>评论组件</div>
}
