export const SET_CHANNEL = 'SET_CHANNEL'
export const CHANGE_ACTIVE = 'CHANGE_ACTIVE'
export const SET_NEWS = 'SET_NEWS'
