// 1. 导入useEffect
import { useState, useEffect } from 'react'

export default function App() {
  const [count, setCount] = useState(0)

  // componentDidMount + componentDidUpdate
  useEffect(() => {
    // 2. 处理副作用
    // useEffect: 回调函数 会在每次组件渲染后执行
    document.title = '被点击了' + count + '次'
    console.log('副作用执行')
  })

  return (
    <div>
      <h1>根组件</h1>
      <div>点击次数：{count}</div>
      <button onClick={() => setCount(count + 1)}>点击</button>
    </div>
  )
}
