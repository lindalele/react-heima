import { useState } from 'react'
/* 
  1. useState可以调用多次，可以提供多个状态
  2. useState只能在函数中使用， 不能嵌套在if else for 函数 中使用
  3. 因为多次调用useState依赖调用的顺序来识别状态
*/
export default function App() {
  console.log('render')

  // useState的参数是初始值，，，useState的参数也可以是一个函数
  const [count, setCount] = useState(0)
  const handleClick = () => {
    setCount(count + 1)
  }

  const [money, setMoney] = useState(100)

  return (
    <div>
      <h1>根组件</h1>
      <div>点击次数：{count}</div>
      <div>金钱：{money}</div>
      <button onClick={handleClick}>点击</button>
      <button onClick={() => setMoney(money + 100)}>挣钱</button>
    </div>
  )
}
