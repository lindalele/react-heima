import React, { Component, createRef } from 'react'

export default class App extends Component {
  state = {
    showInput: false
  }
  inputRef = createRef()
  render() {
    return (
      <div>
        <h1>我是根组件</h1>
        {this.state.showInput ? (
          <input ref={this.inputRef} type="text" placeholder="请输入你的回复" />
        ) : (
          <button onClick={this.handleClick}>回复</button>
        )}
      </div>
    )
  }
  // componentDidMount() {
  //   document.querySelector('button').onclick = () => {
  //     this.setState({
  //       showInput: true
  //     })
  //     this.inputRef.current.focus()
  //   }
  // }
  handleClick = () => {
    this.setState({
      showInput: true
    })
    console.log(this.state.showInput)
    this.inputRef.current.focus()
  }
}
