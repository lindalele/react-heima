import React, { Component } from 'react'
import { createRef } from 'react/cjs/react.development'

class DouDou extends Component {
  componentDidMount() {
    this.timerId = setInterval(function () {
      console.log('别打我，我是豆豆')
    }, 1000)

    window.addEventListener('mousemove', this.mouseFn)
  }
  mouseFn = (e) => {
    console.log(e.pageX, e.pageY)
  }
  render() {
    return (
      <div>
        <h3>豆豆组件--{this.props.count}</h3>
      </div>
    )
  }
  componentDidUpdate() {
    console.log('doudou componentDidUpdate')
  }

  componentWillUnmount() {
    console.log('豆豆凉了')
    window.clearInterval(this.timerId)
    window.removeEventListener('mousemove', this.mouseFn)
  }
}

export default class App extends Component {
  // 类的构造函数
  // 适合给组件初始化数据
  constructor() {
    super()
    this.state = {
      count: 0
    }
    this.aRef = createRef()
    console.log('constructor执行了')
  }
  // state = {}
  // aRef = createRef()

  render() {
    console.log('render执行了')
    return (
      <div>
        <h1>
          根组件-{this.state.msg}-
          <button onClick={this.handleClick}>打豆豆</button>
          <hr />
          {this.state.count < 5 ? (
            <DouDou count={this.state.count}></DouDou>
          ) : (
            <div>豆豆被打死了~</div>
          )}
        </h1>
      </div>
    )
  }
  handleClick = () => {
    this.setState({
      count: this.state.count + 1
    })
    // 强制更新
    // this.forceUpdate()
  }
  componentDidMount() {
    console.log('componentDidMount执行')
  }
  componentDidUpdate() {
    console.log('componentDidUpdate执行')
    // this.setState({})
  }
}
