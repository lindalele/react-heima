import React, { Component } from 'react'

export default class App extends Component {
  state = {
    count: 0
  }
  render() {
    return (
      <div>
        <h1>
          根组件-{this.state.count}-
          <button onClick={this.handleClick}>打豆豆</button>
        </h1>
      </div>
    )
  }
  handleClick = () => {
    // 更新数据  更新DOM
    this.setState(
      (preState) => {
        return {
          count: preState.count + 1
        }
      },
      () => {
        console.log('会等待setState执行结束后才会执行')
        console.log(this.state.count)
        console.log(document.querySelector('h1').innerText)
      }
    )
    // this.setState((preState) => {
    //   return {
    //     count: preState.count + 1
    //   }
    // })
    // this.setState((preState) => {
    //   return {
    //     count: preState.count + 1
    //   }
    // })
  }
}
