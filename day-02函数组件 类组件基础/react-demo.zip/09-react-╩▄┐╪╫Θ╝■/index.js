import { Component } from 'react'
import ReactDOM from 'react-dom'
class App extends Component {
  state = {
    msg: 'hello',
    isDog: false
  }
  render() {
    return (
      <div>
        <h3>受控组件</h3>
        {/* 受控组件：表单元素的value值受到了react的state的控制，称为受控组件 */}
        <input
          type="text"
          value={this.state.msg}
          onChange={this.handleChange}
        />
        <label htmlFor="isDog">是否单身：</label>
        <input
          id="isDog"
          type="checkbox"
          checked={this.state.isDog}
          onChange={this.handleDog}
        />
      </div>
    )
  }
  handleChange = (e) => {
    this.setState({
      msg: e.target.value
    })
  }
  handleDog = (e) => {
    this.setState({
      isDog: e.target.checked
    })
  }
}

ReactDOM.render(<App />, document.getElementById('root'))
