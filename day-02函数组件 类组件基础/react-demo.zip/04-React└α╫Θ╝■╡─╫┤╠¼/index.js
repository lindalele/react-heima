import { Component } from 'react'
import ReactDOM from 'react-dom'

class App extends Component {
  state = {
    count: 0,
    money: 100,
    list: ['黑马程序员', '传智播客']
  }
  render() {
    return (
      <div>
        <h3>这是App组件</h3>
        <div>点击次数：{this.state.count}</div>
        <div>金钱：{this.state.money}</div>
        <ul>
          {this.state.list.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
      </div>
    )
  }
}

ReactDOM.render(<App />, document.getElementById('root'))
