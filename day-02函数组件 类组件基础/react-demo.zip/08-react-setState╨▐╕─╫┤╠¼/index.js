import { Component } from 'react'
import ReactDOM from 'react-dom'
class App extends Component {
  state = {
    count: 0,
    money: 100,
    car: '小黄车',
    list: [1, 2, 3],
    obj: {
      name: 'zs',
      age: 18
    }
  }
  render() {
    return (
      <div>
        <h3>这是App组件</h3>
        <div>
          点击次数：{this.state.count}
          <div>数组：{this.state.list}</div>
          <div>
            {this.state.obj.name} -{this.state.obj.age}
          </div>
          <button onClick={this.handleClick}>点我</button>
        </div>
      </div>
    )
  }

  handleClick = () => {
    // console.log(this.state.count)
    // this.state.count++
    // this.state.list.push(4)
    // this.setState({
    //   count: this.state.count + 1
    // })
    // this.state.obj.name = 'ls'
    this.setState({
      // list: [...this.state.list, 4]
      obj: {
        ...this.state.obj,
        name: 'ls'
      }
    })
  }
}

ReactDOM.render(<App />, document.getElementById('root'))
