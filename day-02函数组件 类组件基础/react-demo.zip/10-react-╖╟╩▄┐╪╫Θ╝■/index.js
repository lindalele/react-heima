import { Component, createRef } from 'react'
import ReactDOM from 'react-dom'
class App extends Component {
  aRef = createRef()

  render() {
    return (
      <div>
        <h3>受控组件</h3>
        <input type="text" ref={this.aRef} />{' '}
        <button onClick={this.handleClick}>获取值</button>
      </div>
    )
  }
  handleClick = () => {
    console.log(this.aRef.current.value)
  }
}

ReactDOM.render(<App />, document.getElementById('root'))
