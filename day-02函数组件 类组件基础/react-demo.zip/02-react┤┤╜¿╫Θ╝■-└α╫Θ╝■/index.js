import ReactDOM from 'react-dom'
import { Component } from 'react'

// 定义类组件
class Hello extends Component {
  render() {
    return <div>我是Hello组件</div>
  }
}

class Demo extends Component {
  render() {
    return <div>我是Demo组件</div>
  }
}

const element = (
  <div>
    <h1>类组件</h1>
    <Hello></Hello>
    <Demo></Demo>
  </div>
)

ReactDOM.render(element, document.getElementById('root'))
