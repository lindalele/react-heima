import ReactDOM from 'react-dom'

// 函数组件：使用js的函数或者箭头函数创建的组件
const isLoading = true
function Hello() {
  if (isLoading) {
    return <div>正在加载中...</div>
  }
  return null
}

const Demo = () => <div>我是demo组件</div>

const element = (
  <div>
    <h1>函数组件</h1>
    <Hello></Hello>
    <Hello></Hello>
    <Hello></Hello>
    <Demo></Demo>
  </div>
)

ReactDOM.render(element, document.getElementById('root'))
