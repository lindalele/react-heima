import { Component } from 'react'
import ReactDOM from 'react-dom'
class App extends Component {
  state = {
    count: 0,
    money: 100,
    list: ['黑马程序员', '传智播客']
  }
  render() {
    return (
      <div>
        <h3>这是App组件</h3>
        <div>
          点击次数：{this.state.count}
          <a href="http://www.baidu.com" onClick={this.handleClick}>
            点我
          </a>
        </div>
      </div>
    )
  }

  handleClick(e) {
    // 阻止浏览器默认行为
    e.preventDefault()
    e.stopPropagation()
    console.log('点击事件')
    console.log(this)
  }
  fn() {
    console.log('mouseenter')
  }
}

ReactDOM.render(<App />, document.getElementById('root'))
