export type LocationType = {
  from: string
} | null
