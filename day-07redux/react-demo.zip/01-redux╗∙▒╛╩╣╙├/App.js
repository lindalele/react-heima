import store from './store'
import { addMore, addOne, subMore, subOne } from './store/action'
export default function App() {
  // 通过redux实现金钱管理
  // 通过store.getState() 就可以获取到store的状态
  const handleClick = () => {
    store.dispatch(addOne())
    console.log(store.getState())
  }
  return (
    <div>
      <h1>我是根组件</h1>
      <div>当前的金钱：</div>
      <div>
        <button onClick={handleClick}>+1</button>
        <button onClick={() => store.dispatch(subOne())}>-1</button>
        <button onClick={() => store.dispatch(addMore(5))}>+5</button>
        <button onClick={() => store.dispatch(subMore(5))}>-5</button>
        <button>+10</button>
        <button>-10</button>
      </div>
    </div>
  )
}
