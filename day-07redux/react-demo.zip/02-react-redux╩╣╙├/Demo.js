import React from 'react'
import { useSelector } from 'react-redux'

export default function Demo() {
  const money = useSelector((state) => state.money)
  return <div>{money}</div>
}
