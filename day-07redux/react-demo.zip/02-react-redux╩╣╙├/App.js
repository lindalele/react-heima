import { useDispatch } from 'react-redux'
import { useSelector } from 'react-redux'
import { addMore, addOne, subMore, subOne, setName } from './store/action'
import Demo from './Demo'
export default function App() {
  // 通过redux实现金钱管理
  // 通过store.getState() 就可以获取到store的状态
  const money = useSelector((state) => {
    return state.money
  })
  const user = useSelector((state) => state.user)
  const dispatch = useDispatch()
  return (
    <div>
      <h1>我是根组件</h1>
      <div>当前的金钱：{money}</div>
      <div>
        <button onClick={() => dispatch(addOne())}>+1</button>
        <button onClick={() => dispatch(subOne())}>-1</button>
        <button onClick={() => dispatch(addMore(5))}>+5</button>
        <button onClick={() => dispatch(subMore(5))}>-5</button>
        <button>+10</button>
        <button>-10</button>

        <hr />
        <Demo></Demo>

        <hr />
        <hr />
        <hr />
        <hr />
        <hr />
        <div>
          <h3>用户管理</h3>
          <div>用户名：{user.name}</div>
          <div>用户密码：{user.password}</div>
          <button onClick={() => dispatch(setName('ls'))}>修改用户名</button>
        </div>
      </div>
    </div>
  )
}
