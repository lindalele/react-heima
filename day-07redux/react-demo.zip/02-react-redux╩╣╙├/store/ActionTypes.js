export const SET_NAME = 'user/setName'
export const SUB_MORE = 'money/subMore'
