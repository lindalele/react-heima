// 取整
// Math.ceil()  Math.round() Math.floor()  parseInt()
// 位运算符进行取整 二进制
// 结论： | 0
// 位运算符的特点：1. 忽略小数 2. 变成二进制进行运算
// | & 位运算符
// console.log(1.111 | 1)
// console.log(2.111 | 2)
// console.log(-2.111 | 3)
// console.log(-1.111 | 1)

// 十进制  =》 二进制
// 1110
// 64 32 16 8 4 2 1
// 十进制 22
//        10110

// 1011
// 0000

// 0011

// console.log(11 & 7)
